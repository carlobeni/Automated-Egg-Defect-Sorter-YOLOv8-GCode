# egg detection 2 > 2025-04-30 7:09pm
https://universe.roboflow.com/eggs-hcgmj/egg-detection-2

Provided by a Roboflow user
License: CC BY 4.0

